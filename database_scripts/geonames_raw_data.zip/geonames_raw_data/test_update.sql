CREATE TABLE IF NOT EXISTS geoname_test_update ( 
geonameid int PRIMARY KEY, 
name varchar(200), 
asciiname varchar(200), 
alternatenames varchar(4000), 
latitude decimal(10,7), 
longitude decimal(10,7), 
fclass char(1), 
fcode varchar(10), 
country varchar(2), 
cc2 varchar(60), 
admin1 varchar(20), 
admin2 varchar(80), 
admin3 varchar(20), 
admin4 varchar(20), 
population int, 
elevation int, 
gtopo30 int, 
timezone varchar(40), 
moddate date 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS alternatename_test_update ( 
alternatenameId int PRIMARY KEY, 
geonameid int, 
isoLanguage varchar(7), 
alternateName varchar(200), 
isPreferredName boolean, 
isShortName boolean, 
isColloquial boolean, 
isHistoric boolean 
) CHARACTER SET utf8; 

DELETE FROM geoname_test_update WHERE geonameid IN (SELECT geonameid from geoname_delete);

UPDATE geoname_test_update dest
inner join geoname_update src on
    dest.geonameid= src.geonameid
set
	dest.name = src.name, 
	dest.asciiname = src.asciiname, 
	dest.alternatenames = src.alternatenames, 
	dest.latitude = src.latitude, 
	dest.longitude = src.longitude, 
	dest.fclass = src.fclass, 
	dest.fcode = src.fcode, 
	dest.country = src.country, 
	dest.cc2 = src.cc2, 
	dest.admin1 = src.admin1, 
	dest.admin2 = src.admin2, 
	dest.admin3 = src.admin3, 
	dest.admin4 = src.admin4, 
	dest.population = src.population, 
	dest.elevation = src.elevation, 
	dest.gtopo30 = src.gtopo30, 
	dest.timezone = src.timezone, 
	dest.moddate = src.moddate;
	
DELETE FROM alternatename_test_update WHERE alternatenameId IN (SELECT alternatenameId from alternatename_delete);

UPDATE alternatename_test_update dest
inner join alternatename_update src on
    dest.alternatenameId = src.alternatenameId
set
	dest.geonameid = src.geonameid,
	dest.isoLanguage = src.isoLanguage,
	dest.alternateName = src.alternateName,
	dest.isPreferredName = src.isPreferredName,
	dest.isShortName = src.isShortName,
	dest.isColloquial = src.isColloquial,
	dest.isHistoric = src.isHistoric;
$client = new-object System.Net.WebClient
$client.DownloadFile("http://download.geonames.org/export/dump/allCountries.zip","data/allCountries.zip")
$client.DownloadFile("http://download.geonames.org/export/dump/alternateNames.zip","data/alternateNames.zip")
$client.DownloadFile("http://download.geonames.org/export/dump/admin1Codes.txt","data/admin1Codes.txt")
$client.DownloadFile("http://download.geonames.org/export/dump/admin1CodesASCII.txt","data/admin1CodesASCII.txt")
$client.DownloadFile("http://download.geonames.org/export/dump/featureCodes_en.txt","data/featureCodes_en.txt")
$client.DownloadFile("http://download.geonames.org/export/dump/timeZones.txt","data/timeZones.txt")
$client.DownloadFile("http://download.geonames.org/export/dump/countryInfo.txt","data/countryInfo.txt")
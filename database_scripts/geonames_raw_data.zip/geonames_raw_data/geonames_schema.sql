CREATE DATABASE IF NOT EXISTS geonames; 
USE geonames; 

CREATE TABLE IF NOT EXISTS geoname ( 
geonameid int PRIMARY KEY, 
name varchar(200), 
asciiname varchar(200), 
alternatenames varchar(4000), 
latitude decimal(10,7), 
longitude decimal(10,7), 
fclass char(1), 
fcode varchar(10), 
country varchar(2), 
cc2 varchar(60), 
admin1 varchar(20), 
admin2 varchar(80), 
admin3 varchar(20), 
admin4 varchar(20), 
population int, 
elevation int, 
gtopo30 int, 
timezone varchar(40), 
moddate date 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS alternatename ( 
alternatenameId int PRIMARY KEY, 
geonameid int, 
isoLanguage varchar(7), 
alternateName varchar(200), 
isPreferredName boolean, 
isShortName boolean, 
isColloquial boolean, 
isHistoric boolean 
) CHARACTER SET utf8; 

CREATE INDEX alternatename_geonameid ON alternatename(geonameid);

CREATE TABLE IF NOT EXISTS countryinfo ( 
iso_alpha2 char(2), 
iso_alpha3 char(3), 
iso_numeric integer, 
fips_code character varying(3), 
name character varying(200), 
capital character varying(200), 
areainsqkm double precision, 
population integer, 
continent char(2), 
tld char(3), 
currency char(3), 
currencyName char(20), 
Phone char(10), 
postalCodeFormat char(20), 
postalCodeRegex char(20), 
geonameId int,
languages character varying(200), 
neighbours char(20), 
equivalentFipsCode char(10) 
) CHARACTER SET utf8; 

CREATE INDEX countryinfo_geonameId ON countryinfo(geonameId);

CREATE TABLE IF NOT EXISTS iso_languagecodes( 
iso_639_3 CHAR(4), 
iso_639_2 VARCHAR(50), 
iso_639_1 VARCHAR(50), 
language_name VARCHAR(200) 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS admin1Codes ( 
code CHAR(6), 
name TEXT 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS admin1CodesAscii ( 
code CHAR(6), 
name TEXT, 
nameAscii TEXT, 
geonameid int 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS featureCodes ( 
code CHAR(7), 
name VARCHAR(200), 
description TEXT 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS timeZones ( 
timeZoneId VARCHAR(200), 
GMT_offset DECIMAL(3,1), 
DST_offset DECIMAL(3,1) 
) CHARACTER SET utf8; 


CREATE TABLE IF NOT EXISTS continentCodes ( 
code CHAR(2), 
name VARCHAR(20), 
geonameid INT 
) CHARACTER SET utf8; 

/*
Tables for data update.
*/

CREATE TABLE IF NOT EXISTS alternatename_update ( 
alternatenameId int PRIMARY KEY, 
geonameid int, 
isoLanguage varchar(7), 
alternateName varchar(200), 
isPreferredName boolean, 
isShortName boolean, 
isColloquial boolean, 
isHistoric boolean 
) CHARACTER SET utf8; 

CREATE TABLE IF NOT EXISTS geoname_update ( 
geonameid int PRIMARY KEY, 
name varchar(200), 
asciiname varchar(200), 
alternatenames varchar(4000), 
latitude decimal(10,7), 
longitude decimal(10,7), 
fclass char(1), 
fcode varchar(10), 
country varchar(2), 
cc2 varchar(60), 
admin1 varchar(20), 
admin2 varchar(80), 
admin3 varchar(20), 
admin4 varchar(20), 
population int, 
elevation int, 
gtopo30 int, 
timezone varchar(40), 
moddate date 
) CHARACTER SET utf8; 

CREATE TABLE IF NOT EXISTS alternatename_delete ( 
alternatenameId int PRIMARY KEY, 
geonameid int, 
name varchar(200),
cmt varchar(255)
) CHARACTER SET utf8; 

CREATE TABLE IF NOT EXISTS geoname_delete ( 
geonameid int PRIMARY KEY, 
name varchar(200), 
cmt varchar(255)
) CHARACTER SET utf8; 
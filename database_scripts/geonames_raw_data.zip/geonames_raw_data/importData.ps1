$dbuser = "root"
$dbpassword = ""
$mysql_path = "C:/wamp/bin/mysql/mysql5.5.24/bin"
$raw_data_path = "E:/geonames_raw_data/data"

& cd E:\geonames_raw_data
& E:

# Get data from geonames
# This script uses PowerShell. 
# If executed on a 64bit machine, please setup execution policy using 'Set-ExecutionPolicy Unrestricted'

<#
$geonames_dump = "http://download.geonames.org/export/dump"
$geonames_datas = @("allCountries.zip", 
				   "alternateNames.zip", 
				   "admin1Codes.txt", 
				   "admin1CodesASCII.txt", 
				   "featureCodes_en.txt", 
				   "timeZones.txt", 
				   "countryInfo.txt")

HttpContext.Current.Server.ScriptTimeout = 900; # in seconds
$client = new-object System.Net.WebClient
foreach ($geonames_data in $geonames_datas)
{
	& echo "downloading data from $geonames_dump/$geonames_data"
	$client.DownloadFile("$geonames_dump/$geonames_data","$raw_data_path/$geonames_data")
}
#>

#& 7z x "$raw_data_path/*.zip" "-o$raw_data_path"
#& del "$raw_data_path/allCountries.zip"
#& del "$raw_data_path/alternateNames.zip"

$load_sqls = @("LOAD DATA INFILE '$raw_data_path/allCountries.txt' INTO TABLE geoname CHARACTER SET utf8 (geonameid,name,asciiname,alternatenames,latitude,longitude,fclass,fcode,country,cc2, admin1,admin2,admin3,admin4,population,elevation,gtopo30,timezone,moddate);", 
			   "LOAD DATA INFILE '$raw_data_path/alternateNames.txt' INTO TABLE alternatename CHARACTER SET utf8 (alternatenameid,geonameid,isoLanguage,alternateName,isPreferredName,isShortName,isColloquial,isHistoric); ", 
			   "LOAD DATA INFILE '$raw_data_path/iso-languagecodes.txt' INTO TABLE iso_languagecodes CHARACTER SET utf8 (iso_639_3, iso_639_2, iso_639_1, language_name); ", 
			   "LOAD DATA INFILE '$raw_data_path/admin1Codes.txt' INTO TABLE admin1Codes CHARACTER SET utf8 (code, name); ", 
			   "LOAD DATA INFILE '$raw_data_path/admin1CodesAscii.txt' INTO TABLE admin1CodesAscii CHARACTER SET utf8 (code, name, nameAscii, geonameid); ", 
			   "LOAD DATA INFILE '$raw_data_path/featureCodes_en.txt' INTO TABLE featureCodes CHARACTER SET utf8 (code, name, description); ", 
			   "LOAD DATA INFILE '$raw_data_path/timeZones.txt' INTO TABLE timeZones CHARACTER SET utf8 IGNORE 1 LINES (timeZoneId, GMT_offset, DST_offset); ",
			   "LOAD DATA INFILE '$raw_data_path/countryInfo.txt' INTO TABLE countryInfo CHARACTER SET utf8 IGNORE 1 LINES (iso_alpha2,iso_alpha3,iso_numeric,fips_code,name,capital,areaInSqKm,population,continent,languages,currency,geonameId); ",
			   "LOAD DATA INFILE '$raw_data_path/continentCodes.txt' INTO TABLE continentCodes CHARACTER SET utf8 FIELDS TERMINATED BY ',' (code, name, geonameId); ")

&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "source geonames_schema.sql;"
foreach ($load_sql in $load_sqls)
{
	&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; $load_sql"
}

<#
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/allCountries.txt' INTO TABLE geoname CHARACTER SET utf8 (geonameid,name,asciiname,alternatenames,latitude,longitude,fclass,fcode,country,cc2, admin1,admin2,admin3,admin4,population,elevation,gtopo30,timezone,moddate);"
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/alternateNames.txt' INTO TABLE alternatename CHARACTER SET utf8 (alternatenameid,geonameid,isoLanguage,alternateName,isPreferredName,isShortName,isColloquial,isHistoric); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/iso-languagecodes.txt' INTO TABLE iso_languagecodes CHARACTER SET utf8 (iso_639_3, iso_639_2, iso_639_1, language_name); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/admin1Codes.txt' INTO TABLE admin1Codes CHARACTER SET utf8 (code, name); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/admin1CodesAscii.txt' INTO TABLE admin1CodesAscii CHARACTER SET utf8 (code, name, nameAscii, geonameid); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/featureCodes_en.txt' INTO TABLE featureCodes CHARACTER SET utf8 (code, name, description); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/timeZones.txt' INTO TABLE timeZones CHARACTER SET utf8 IGNORE 1 LINES (timeZoneId, GMT_offset, DST_offset); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/countryInfo.txt' INTO TABLE countryInfo CHARACTER SET utf8 IGNORE 1 LINES (iso_alpha2,iso_alpha3,iso_numeric,fips_code,name,capital,areaInSqKm,population,continent,languages,currency,geonameId); "
&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; LOAD DATA INFILE '$raw_data_path/continentCodes.txt' INTO TABLE continentCodes CHARACTER SET utf8 FIELDS TERMINATED BY ',' (code, name, geonameId); "
#>
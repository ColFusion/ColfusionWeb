$dbuser = "root"
$dbpassword = ""
$mysql_path = "C:/wamp/bin/mysql/mysql5.5.24/bin"
$dataDir = "E:/geonames_raw_data/updates"

$yesterday = [DateTime]::Today.AddDays(-1)
$DateStr = '{0:yyyy-MM-dd}' -f $yesterday

$geoname_update = "modifications-" + $DateStr + ".txt"
$geoname_delete = "deletes-" + $DateStr + ".txt"
$altername_update = "alternateNamesModifications-" + $DateStr + ".txt"
$altername_delete = "alternateNamesDeletes-" + $DateStr + ".txt"

$geonames_dump = "http://download.geonames.org/export/dump/"

$client = new-object System.Net.WebClient
$client.DownloadFile($geonames_dump + $geoname_update, $dataDir + "/" + $geoname_update)
$client.DownloadFile($geonames_dump + $geoname_delete, $dataDir + "/" + $geoname_delete)
$client.DownloadFile($geonames_dump + $altername_update, $dataDir + "/" + $altername_update)
$client.DownloadFile($geonames_dump + $altername_delete, $dataDir + "/" + $altername_delete)

$update_sqls = @("LOAD DATA INFILE '$dataDir/$geoname_update' INTO TABLE geoname_update CHARACTER SET utf8 (geonameid,name,asciiname,alternatenames,latitude,longitude,fclass,fcode,country,cc2, admin1,admin2,admin3,admin4,population,elevation,gtopo30,timezone,moddate);", 
			   "LOAD DATA INFILE '$dataDir/$altername_update' INTO TABLE alternatename_update CHARACTER SET utf8 (alternatenameid,geonameid,isoLanguage,alternateName,isPreferredName,isShortName,isColloquial,isHistoric);", 
			   "LOAD DATA INFILE '$dataDir/$geoname_delete' INTO TABLE geoname_delete CHARACTER SET utf8 (geonameid,name,cmt); ", 
			   "LOAD DATA INFILE '$dataDir/$altername_delete' INTO TABLE alternatename_delete CHARACTER SET utf8 (alternatenameid,geonameid,name,cmt); ")

foreach ($update_sql in $update_sqls)
{
	&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; $update_sql"
}

&"$mysql_path/mysql" --user=$dbuser --password=$dbpassword -e "use geonames; source updateData.sql"
<?php
include_once('Smarty.class.php');
$main_smarty = new Smarty; 

include('config.php');
include(mnminclude.'html1.php');
include(mnminclude.'link.php');
include(mnminclude.'tags.php');
include(mnminclude.'user.php');
include(mnminclude.'smartyvariables.php');

$path_to_jar = mnmpath.'pdftest/jar';
//echo $path_to_jar.'</br>';
$path_to_jai = $path_to_jar.'jai';
$dir_with_pdf_files = mnmpath.'pdftest/Inter1.pdf';
$output = mnmpath.'pdftest';

$command = "java  -Dorg.jpedal.jai=true -cp $path_to_jar/jpdf2html.jar:$path_to_jai/jai_codec.jar:$path_to_jai/jai_core.jar.jar:$path_to_jai/jai_imageio.jar org/jpedal/examples/html/ExtractPagesAsHTML $dir_with_pdf_files $output";

exec($command, $output);

echo $command.'</br>';
print_r($output);

?>